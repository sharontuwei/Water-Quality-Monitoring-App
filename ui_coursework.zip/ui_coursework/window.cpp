#include <QtWidgets>
#include <vector>
#include <QString>
#include "window.hpp"
#include "stats.hpp"
#include "dataset.hpp"
#include "pollutionWindow.hpp"

static const int MIN_WIDTH = 620;

WaterQualityWindow::WaterQualityWindow(QWidget* parent) : QMainWindow(parent), statsDialog(nullptr)
{
    createMainWidget();
    createFileSelectors();
    createButtons();
    createToolBar();
    createStatusBar();
    addFileMenu();
    addHelpMenu();

    setMinimumWidth(MIN_WIDTH);
    setWindowTitle("Water Quality Tool");
}

void WaterQualityWindow::createMainWidget()
{
    // Create a central widget layout (QVBoxLayout)
    QWidget* centralWidget = new QWidget(this);
    QVBoxLayout* layout = new QVBoxLayout(centralWidget);

    // Title label with Times New Roman font, 20pt, left-aligned
    QLabel* titleLabel = new QLabel(tr("Water Quality Monitoring"), this);
    QFont titleFont("Times New Roman", 20);
    titleLabel->setFont(titleFont);
    titleLabel->setAlignment(Qt::AlignLeft);

    // Add title to layout
    layout->addWidget(titleLabel);

    // Create the QTabWidget
    QTabWidget* tabWidget = new QTabWidget(this);

    // First Tab: Main Dashboard
    QWidget* mainDashboardTab = new QWidget();
    QVBoxLayout* mainDashboardLayout = new QVBoxLayout(mainDashboardTab);

    // Create a grid layout for the cards (2x3 grid, only 6 cards in total)
    QGridLayout* gridLayout = new QGridLayout();
    mainDashboardLayout->addLayout(gridLayout);

    // Set stretch factors for rows and columns to ensure uniformity
    gridLayout->setRowStretch(0, 1);
    gridLayout->setRowStretch(1, 1);
    gridLayout->setColumnStretch(0, 1);
    gridLayout->setColumnStretch(1, 1);
    gridLayout->setColumnStretch(2, 1);

    // Create 5 empty cards with a title and a button
    QStringList cardNames = {"Pollutant Overview Page", "Persistent Organic Pollutants (POPs) Page",
                             "Environmental Litter Indicators Page", "Fluorinated Compounds Page", "Compliance Dashboard"};

    for (int i = 0; i < 5; ++i) {
        QWidget* card = new QWidget(this);
        card->setStyleSheet("background-color: #ebf4f5"); // Lighter blue background
        card->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);  // Allow the card to expand in both directions

        // Set a minimum size for the cards
        card->setMinimumSize(150, 150);

        // Create a layout for the card
        QVBoxLayout* cardLayout = new QVBoxLayout(card);

        // Title label for the card (center aligned)
        QLabel* cardTitle = new QLabel(cardNames[i], card);
        cardTitle->setFont(QFont("Times New Roman", 16)); // Set font to Times New Roman 16pt
        cardTitle->setAlignment(Qt::AlignCenter); // Center the title horizontally
        cardTitle->setWordWrap(true); // Enable word wrapping
        cardTitle->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding); // Allow QLabel to expand

        // Add title to the layout
        cardLayout->addWidget(cardTitle, 0, Qt::AlignCenter);

        // Create a push button with label "Visit"
        QPushButton* cardButton = new QPushButton("Visit", card);
        cardButton->setFont(QFont("Times New Roman", 16));  // Set font to Times New Roman 16pt
        cardButton->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);  // Set button size
        cardButton->setStyleSheet("background-color: white");

        // Add the button to the bottom of the card
        cardLayout->addWidget(cardButton);

        // Add the card to the grid layout
        gridLayout->addWidget(card, i / 3, i % 3); // Arrange in a 2x3 grid
    }

    // Table in the 6th card (positioned at index 5)
    QWidget* tableCard = new QWidget(this);
    tableCard->setStyleSheet("background-color: #ebf4f5"); // Lighter blue background
    tableCard->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding); // Allow table card to expand

    // Set a minimum size for the table card
    tableCard->setMinimumSize(150, 150);

    // Create a layout for the table card
    QVBoxLayout* tableCardLayout = new QVBoxLayout(tableCard);

    // Create the table widget and set its model
    table = new QTableView();
    table->setModel(&waterQualityModel);

    // Set the table's size policy to allow it to fit inside the card
    table->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding); // Allow the table to expand within the card

    // Add the table to the tableCard layout
    tableCardLayout->addWidget(table);
    tableCardLayout->setStretch(0, 1);  // Allow the table to take up available space in the card

    // Create a push button for the 6th card
    QPushButton* tableCardButton = new QPushButton(tr("Visit"), tableCard);
    tableCardButton->setFont(QFont("Times New Roman", 16));
    tableCardButton->setStyleSheet("background-color: white");
    tableCardButton->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
    tableCardLayout->addWidget(tableCardButton);  // Add button to the table card

    // Add the tableCard to the grid at position (1, 2), spanning 2 columns
    gridLayout->addWidget(tableCard, 1, 2, 1, 1);  // Position the table in the 6th card (spanning 2 columns)

    // Add the Main Dashboard tab to the tab widget
    tabWidget->addTab(mainDashboardTab, "Main Dashboard");

    PollutionWindow* pollutionWindow = new PollutionWindow(tabWidget);
    tabWidget->addTab(pollutionWindow, tr("Pollution Overview"));

    // Add the other tabs (empty for now)
    tabWidget->addTab(new QWidget(), tr("Persistent Organic Pollutants (POPs) Page"));
    tabWidget->addTab(new QWidget(), tr("Environmental Litter Indicators Page"));
    tabWidget->addTab(new QWidget(), tr("Fluorinated Compounds Page"));
    tabWidget->addTab(new QWidget(), tr("Compliance Dashboard"));

    // Create the table widget and set its model
    table = new QTableView();
    table->setModel(&waterQualityModel);

    // Set the table's size policy to allow it to fit inside the card
    table->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding); // Allow the table to expand within the card

    // Add the table to the tableCard layout
    tableCardLayout->addWidget(table);
    tableCardLayout->setStretch(0, 1);

    QWidget* dataPageTab = new QWidget();
    QVBoxLayout* dataPageLayout = new QVBoxLayout(dataPageTab);
    dataPageLayout->addWidget(table); // Add the table to the "Data Page" tab

    // Add the "Data Page" tab to the tab widget
    tabWidget->addTab(dataPageTab, tr("Data Page"));
    layout->addWidget(tabWidget);

    // Add the tab widget to the layout
    layout->addWidget(tabWidget);

    // Set the central widget of the main window
    setCentralWidget(centralWidget);
}

void WaterQualityWindow::createFileSelectors()
{
    // Country filter options (Y for Yorkshire, WT for another country)
    QStringList countryOptions;
    countryOptions << "Y" << "WT";
    countryFilter = new QComboBox();
    countryFilter->addItems(countryOptions);

    // Year filter options (2018-2024)
    QStringList yearOptions;
    for (int i = 2018; i <= 2024; ++i) {
        yearOptions << QString::number(i);
    }
    yearFilter = new QComboBox();
    yearFilter->addItems(yearOptions);
}
void WaterQualityWindow::createButtons()
{
    loadButton = new QPushButton("Load");
    statsButton = new QPushButton("Stats");

    connect(loadButton, SIGNAL(clicked()), this, SLOT(openCSV()));
    connect(statsButton, SIGNAL(clicked()), this, SLOT(displayStats()));
}

void WaterQualityWindow::createToolBar()
{
    QToolBar* toolBar = new QToolBar();

    QLabel* countryLabel = new QLabel("Country");
    countryLabel->setAlignment(Qt::AlignVCenter);
    toolBar->addWidget(countryLabel);
    toolBar->addWidget(countryFilter);

    QLabel* yearLabel = new QLabel("Year");
    yearLabel->setAlignment(Qt::AlignVCenter);
    toolBar->addWidget(yearLabel);
    toolBar->addWidget(yearFilter);

    toolBar->addSeparator();

    toolBar->addWidget(loadButton);
    toolBar->addWidget(statsButton);

    addToolBar(Qt::LeftToolBarArea, toolBar);
}

void WaterQualityWindow::createStatusBar()
{
    fileInfo = new QLabel("Current file: <none>");
    QStatusBar* status = statusBar();
    status->addWidget(fileInfo);
}

void WaterQualityWindow::addFileMenu()
{
    QAction* locAction = new QAction("Set Data &Location", this);
    locAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_L));
    connect(locAction, SIGNAL(triggered()), this, SLOT(setDataLocation()));

    QAction* closeAction = new QAction("Quit", this);
    closeAction->setShortcut(QKeySequence::Close);
    connect(closeAction, SIGNAL(triggered()), this, SLOT(close()));

    QMenu* fileMenu = menuBar()->addMenu("&File");
    fileMenu->addAction(locAction);
    fileMenu->addAction(closeAction);
}

void WaterQualityWindow::addHelpMenu()
{
    QAction* aboutAction = new QAction("&About", this);
    connect(aboutAction, SIGNAL(triggered()), this, SLOT(about()));

    QAction* aboutQtAction = new QAction("About &Qt", this);
    connect(aboutQtAction, SIGNAL(triggered()), qApp, SLOT(aboutQt()));

    QMenu* helpMenu = menuBar()->addMenu("&Help");
    helpMenu->addAction(aboutAction);
    helpMenu->addAction(aboutQtAction);
}

void WaterQualityWindow::setDataLocation()
{
    QString directory = QFileDialog::getExistingDirectory(
        this, "Data Location", ".",
        QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

    if (directory.length() > 0) {
        dataLocation = directory;
    }
}

void WaterQualityWindow::openCSV()
{
    if (dataLocation == "") {
        QMessageBox::critical(this, "Data Location Error",
                              "Data location has not been set!\n\n"
                              "You can specify this via the File menu."
                              );
        return;
    }

    QString country = countryFilter->currentText();
    QString year = yearFilter->currentText();

    auto filename = QString("%1-%2.csv")
                        .arg(country)
                        .arg(year);

    auto path = dataLocation + "/" + filename;

    try {
        waterQualityModel.updateFromFile(path);
    }
    catch (const std::exception& error) {
        QMessageBox::critical(this, "CSV File Error", error.what());
        return;
    }

    fileInfo->setText(QString("Current file: <kbd>%1</kbd>").arg(filename));
    table->resizeColumnsToContents();

    if (statsDialog != nullptr && statsDialog->isVisible()) {
        statsDialog->update(waterQualityModel.averageResult(), waterQualityModel.maxResult());
    }
}

void WaterQualityWindow::displayStats()
{
    if (waterQualityModel.hasData()) {
        if (statsDialog == nullptr) {
            statsDialog = new StatsDialog(this);
        }

        statsDialog->update(waterQualityModel.averageResult(), waterQualityModel.maxResult());

        statsDialog->show();
        statsDialog->raise();
        statsDialog->activateWindow();
    }
}

void WaterQualityWindow::about()
{
    QMessageBox::about(this, "About Water Quality Tool",
                       "Water Quality Tool displays and analyzes water quality data loaded from"
                       "CSV files containing sample information from various locations.\n\n"
                       "(c) 2024 by Muhammad Muhammad Saiful Wong, Xuhui Shi, Jinghao Shi, Sharon Tuwei, Jia Xin Low");
}
