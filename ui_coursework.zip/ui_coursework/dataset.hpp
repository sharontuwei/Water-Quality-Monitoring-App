#pragma once

#include <vector>
#include <string>
#include <QString>
#include <fstream>
#include <utility>
#include <map>
#include "watersample.hpp" 

struct FilteredSample {
    QString determinandLabel;
    QString dateTime;
    double result;
    QString unitLabel;
    double easting;
    double northing;
};

class WaterQualityDataset {
public:
    WaterQualityDataset() {}
    WaterQualityDataset(const std::string& filename) { loadData(filename); }
    void loadData(const std::string& filename);
    int size() const { return data.size(); }
    WaterSample operator[](int index) const { return data.at(index); }
    WaterSample highestResult() const;
    double meanResult() const;
    size_t complianceSampleCount() const;
    void clear() { data.clear(); }
    
    std::vector<std::pair<std::string, double>> getPollutant(const std::string& determinandLabel);
    
private:
    std::vector<WaterSample> data;
    static std::map<std::string, std::vector<std::pair<std::string, double>>> pollutantData;
    void checkDataExists() const;
};

