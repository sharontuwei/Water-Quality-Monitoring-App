#ifndef POLLUTIONWINDOW_HPP
#define POLLUTIONWINDOW_HPP

#include <QtCharts/QChartView>
#include <QtCharts/QChart>
#include <QtCharts/QValueAxis>
#include <QtCharts/QLineSeries>
#include <QLineEdit>
#include <QListView>
#include <QStringListModel>
#include <QVBoxLayout>
#include <QLabel>
#include <QTableView>
#include <QListWidget>
#include <QFrame>
#include <QSizePolicy>
#include <QGridLayout>
#include <QFont>
#include <QMessageBox>
#include <QStandardItem>
#include <QStandardItemModel>
#include "model.hpp"
#include "dataset.hpp"
#include "watersample.hpp"
#include "stats.hpp"

class PollutionWindow : public QWidget {
    Q_OBJECT

public:
    explicit PollutionWindow(QWidget *parent = nullptr);
    void updatePollutantChart(const QString &pollutantName, int monthFilter);

private:
    void createMainWidget();
    void updatePollutantDescription(const QString &pollutantName);
    void updatePollutantChart(const QString &pollutantName);

    QWidget *centralWidget;
    QMap<QString, QString> pollutantDescriptions;
    QListWidget *pollutantsListWidget;
    WaterQualityModel waterQualityModel;
    WaterQualityDataset dataset;
    QTableView* table;
    QFrame* bottomRightBox;
    QFrame* rightSection;
    QLabel *descriptionLabel;
    QLabel *graphPlaceholder;

    // Declare the chart-related variables
    QChart *chart;  // Pointer to the QChart object
    QValueAxis *axisX;  // Pointer to the X-axis
    QValueAxis *axisY;  // Pointer to the Y-axis
    QChartView *chartView;  // Pointer to the QChartView object
};

#endif 

