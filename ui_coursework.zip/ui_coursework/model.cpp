#include "model.hpp"

void WaterQualityModel::clear() {
    dataset.clear();
}

void WaterQualityModel::updateFromFile(const QString& filename) {
    beginResetModel();
    clear();
    dataset.loadData(filename.toStdString());
    endResetModel();
}

QVariant WaterQualityModel::data(const QModelIndex& index, int role) const {
    if (!index.isValid() || index.row() >= dataset.size()) {
        qDebug() << "Invalid index or out of range. Row:" << index.row() << "Size:" << dataset.size();
        return QVariant();
    }

    if (role == Qt::TextAlignmentRole) {
        return int(Qt::AlignRight | Qt::AlignVCenter);
    } else if (role == Qt::DisplayRole) {
        const WaterSample& sample = dataset[index.row()];

        switch (index.column()) {
        case 0: return QVariant(sample.getId().c_str());
        case 1: return QVariant(sample.getSamplingPoint().c_str());
        case 2: return QVariant(sample.getSamplingPointNotation().c_str());
        case 3: return QVariant(sample.getSamplingPointLabel().c_str());
        case 4: return QVariant(sample.getDateTime().c_str());
        case 5: return QVariant(sample.getDeterminandLabel().c_str());
        case 6: return QVariant(sample.getDeterminandDefinition().c_str());
        case 7: return QVariant(sample.getDeterminandNotation().c_str());
        case 8: return QVariant(sample.getResultQualifier().c_str());
        case 9: return QVariant(sample.getResult());
        case 10: return QVariant(sample.getCodedResultInterpretation().c_str());
        case 11: return QVariant(sample.getUnitLabel().c_str());
        case 12: return QVariant(sample.getSampledMaterialType().c_str());
        case 13: return QVariant(sample.getCompliance() ? "Compliant" : "Non-Compliant");
        case 14: return QVariant(sample.getPurposeLabel().c_str());
        case 15: return QVariant(sample.getEasting());
        case 16: return QVariant(sample.getNorthing());
        default:
            qDebug() << "Unhandled column index:" << index.column();
            return QVariant();
        }
    }

    return QVariant();
}

QVariant WaterQualityModel::headerData(int section, Qt::Orientation orientation, int role) const {
    if (role != Qt::DisplayRole) {
        return QVariant();
    }

    if (orientation == Qt::Vertical) {
        return QVariant(section + 1);  // For vertical headers (row numbers).
    }

    switch (section) {
    case 0: return QString("Sample ID");
    case 1: return QString("Sampling Point");
    case 2: return QString("Sampling Point Notation");
    case 3: return QString("Sampling Point Label");
    case 4: return QString("Date & Time");
    case 5: return QString("Determinand");
    case 6: return QString("Determinand Definition");
    case 7: return QString("Determinand Notation");
    case 8: return QString("Result Qualifier");
    case 9: return QString("Result");
    case 10: return QString("Coded Result Interpretation");
    case 11: return QString("Unit Label");
    case 12: return QString("Sampled Material Type");
    case 13: return QString("Compliance Status");
    case 14: return QString("Purpose Label");
    case 15: return QString("Easting");
    case 16: return QString("Northing");
    default: return QVariant();
    }
}
