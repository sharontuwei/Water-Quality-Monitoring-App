#include <QLineEdit>
#include <QListView>
#include <QStringListModel>
#include <QVBoxLayout>
#include <QLabel>
#include <QTableView>
#include <QFrame>
#include <QSizePolicy>
#include <QGridLayout>
#include <QFont>
#include <QMessageBox>
#include <QtCharts/QChartView>
#include <QtCharts/QChart>
#include <QtCharts/QLineSeries>
#include <QtCharts/QValueAxis>
#include <QStandardItem>
#include <QDate>
#include <QToolTip>
#include <QScatterSeries>
#include <QComboBox>
#include <QGridLayout>
#include <QStandardItemModel>
#include "pollutionWindow.hpp"
#include "model.hpp"
#include "dataset.hpp"
#include "watersample.hpp"
#include "stats.hpp"

PollutionWindow::PollutionWindow(QWidget* parent)
    : QWidget(parent)
{
    createMainWidget();
}

std::map<QString, std::tuple<double, double, double>> thresholds = {
    {"Ammonia(N)", std::make_tuple(0.5, 1.0, 1.5)},  // Safe, Amber, Red (mg/L)
    {"Chloroform", std::make_tuple(0.002, 0.005, 0.01)},  // Safe, Amber, Red (mg/L)
    {"Nitrate-N", std::make_tuple(10.0, 20.0, 30.0)},  // Safe, Amber, Red (mg/L)
    {"Nitrite-N", std::make_tuple(1.0, 2.0, 3.0)},  // Safe, Amber, Red (mg/L)
    {"COD as O2", std::make_tuple(30.0, 50.0, 100.0)},  // Safe, Amber, Red (mg/L)
    {"Chloride Ion", std::make_tuple(250.0, 500.0, 1000.0)},  // Safe, Amber, Red (mg/L)
};

void PollutionWindow::createMainWidget()
{
    setStyleSheet("background-color: #ebf4f5;");

    // Title Label
    QLabel* titleLabel = new QLabel(tr("Pollutant Overview Page"), this);
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setFont(QFont("Times New Roman", 25));  // Set font to Times New Roman, 20pt
    titleLabel->setFixedHeight(55);

    // List of items (pollutants)
    QStringList items = {
        tr("Ammonia(N)"),
        tr("Chloroform"),
        tr("Nitrate-N"),
        tr("Nitrite-N"),
        tr("COD as O2"),
        tr("Chloride Ion"),
    };

    pollutantDescriptions["Ammonia(N)"] =
        tr("<p>This chemical is used as a solvent and is harmful to both human health and aquatic life when released into water bodies.</p>"
        "<p><b>Risk:</b> Ammonia can cause toxicity in aquatic organisms, affecting their respiration and growth. High concentrations can lead to fish kills.</p>"
        "<p><b>Compliance:</b> The environmental safety threshold for ammonia in freshwater is typically 0.02 mg/L. Exceeding this can cause adverse effects on aquatic life.</p>"
        "<p><b>Safety Threshold:</b> The safety threshold for ammonia in drinking water is 0.5 mg/L, but levels in surface waters should remain below 0.02 mg/L for aquatic health.</p>");

    pollutantDescriptions["Chloroform"] =
        tr("<p>Chloroform, a chlorinated solvent, is considered a potential carcinogen and is toxic to aquatic life.</p>"
        "<p><b>Risk:</b> Exposure to chloroform can cause liver and kidney damage, and long-term exposure may increase the risk of cancer.</p>"
        "<p><b>Compliance:</b> The maximum contaminant level (MCL) for chloroform in drinking water is set at 0.08 mg/L in many countries. Higher concentrations may be dangerous.</p>"
        "<p><b>Safety Threshold:</b> Chloroform concentrations in drinking water should not exceed 0.08 mg/L, according to most water quality standards.</p>");

    pollutantDescriptions["Nitrate-N"] =
        tr("<p>Nitrate in water can cause eutrophication and health problems, especially methemoglobinemia in infants.</p>"
        "<p><b>Risk:</b> High levels of nitrates can cause 'blue baby syndrome' in infants, leading to oxygen deprivation. In large quantities, it can contribute to algal blooms in water bodies.</p>"
        "<p><b>Compliance:</b> The safe limit for nitrate in drinking water is typically set at 10 mg/L as nitrogen (NO3-N).</p>"
        "<p><b>Safety Threshold:</b> Nitrate levels above 10 mg/L in drinking water can pose health risks, particularly to infants under six months of age.</p>");

    pollutantDescriptions["Nitrite-N"] =
        tr("<p>Nitrites in water can lead to water toxicity and are linked to adverse health effects such as blue baby syndrome.</p>"
        "<p><b>Risk:</b> Nitrites interfere with the blood's ability to carry oxygen, leading to 'blue baby syndrome' in infants. High levels can also cause fish kills.</p>"
        "<p><b>Compliance:</b> The maximum allowable concentration of nitrite-N in drinking water is 1 mg/L.</p>"
        "<p><b>Safety Threshold:</b> Nitrite concentrations should not exceed 1 mg/L in drinking water for safety.</p>");

    pollutantDescriptions["COD as O2"] =
        tr("<p>Chemical Oxygen Demand (COD) as O2 is a measure of the oxygen required to oxidize organic compounds in water, indicating the level of pollution.</p>"
        "<p><b>Risk:</b> High COD values indicate high levels of organic pollutants in water, which deplete oxygen levels, making it difficult for aquatic life to survive.</p>"
        "<p><b>Compliance:</b> While COD doesn't have a direct regulatory threshold, water bodies should maintain low COD values to avoid oxygen depletion and ecosystem disruption.</p>"
        "<p><b>Safety Threshold:</b> A COD value of less than 10 mg/L is typically considered acceptable for aquatic life; anything higher could lead to hypoxia.</p>");

    pollutantDescriptions["Chloride Ion"] =
        tr("<p>Chloride ions in water are primarily from salts, and high concentrations can harm aquatic organisms and disrupt freshwater ecosystems.</p>"
        "<p><b>Risk:</b> Elevated chloride levels can cause ion imbalance in freshwater organisms, disrupting osmoregulation, leading to fish kills and ecosystem imbalances.</p>"
        "<p><b>Compliance:</b> Chloride concentrations in freshwater should typically not exceed 250 mg/L to avoid harm to aquatic life.</p>"
        "<p><b>Safety Threshold:</b> The guideline for chloride concentration in drinking water is 250 mg/L, but concentrations above 100 mg/L in freshwater can be harmful to aquatic ecosystems.</p>");

    // Create QLineEdit for the search bar
    QLineEdit* searchLineEdit = new QLineEdit(this);
    searchLineEdit->setPlaceholderText(tr("Search for a pollutant..."));

    // Create a QStringListModel to hold the list of items
    QStringListModel* model = new QStringListModel(items, this);

    // Create a QListView to display the list of items
    QListView* listView = new QListView(this);
    listView->setModel(model);
    listView->setFont(QFont("Times New Roman", 12));

    // Create a QLabel for displaying pollutant description
    descriptionLabel = new QLabel(this);
    descriptionLabel->setWordWrap(true);
    descriptionLabel->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    descriptionLabel->setFont(QFont("Times New Roman", 12));

    // Place the description label inside a QScrollArea for scrollability
    QScrollArea* scrollArea = new QScrollArea(this);
    scrollArea->setWidget(descriptionLabel);
    scrollArea->setWidgetResizable(true);

    // Filter the list based on the text entered in the QLineEdit
    connect(searchLineEdit, &QLineEdit::textChanged, [=](const QString& text) {
        QStringList filteredItems = items.filter(text, Qt::CaseInsensitive);
        model->setStringList(filteredItems);
    });

    // When an item is selected in the list view, update the description label and chart
    connect(listView, &QListView::clicked, [=](const QModelIndex& index) {
        QString selectedItem = model->data(index, Qt::DisplayRole).toString();
        if (pollutantDescriptions.contains(selectedItem)) {
            updatePollutantDescription(selectedItem);
            updatePollutantChart(selectedItem);
        }
    });

    // Set the default description for the first item in the list
    if (!items.isEmpty()) {
        QString defaultItem = items.first();
        if (pollutantDescriptions.contains(defaultItem)) {
            updatePollutantDescription(defaultItem);
            updatePollutantChart(defaultItem);
        }
    }

    // Left section: Search Bar, List View, and Description Label
    QFrame* leftSection = new QFrame(this);
    QVBoxLayout* leftLayout = new QVBoxLayout;

    // Use stretch factors to balance heights
    leftLayout->addWidget(searchLineEdit);
    leftLayout->addWidget(listView, 2);  // List View takes 40% of space
    leftLayout->addWidget(scrollArea, 5);  // Description takes 60% of space

    leftSection->setLayout(leftLayout);

    // Right section: Graph setup
    QFrame* rightSection = new QFrame(this);
    QVBoxLayout* rightLayout = new QVBoxLayout;

    chart = new QChart();
    chart->setTitle("Pollutant Levels");

    // X-axis setup: months (1 to 12)
    axisX = new QValueAxis();
    axisX->setTitleText(tr("Month"));
    axisX->setLabelFormat("%d");  // Display as integer
    axisX->setRange(1, 12);       // Set range from 1 to 12 for months
    axisX->setTickCount(12);      // Ensure it ticks at each month (1-12)

    // Y-axis setup: Concentration with units (e.g., mg/L)
    axisY = new QValueAxis();
    axisY->setTitleText(tr("Concentration (ug/L)"));  // Concentration in ug/L or any relevant unit
    axisY->setLabelFormat("%d"); // Display floating-point values with 2 decimal places

    // Add the axes to the chart
    chart->addAxis(axisX, Qt::AlignBottom);
    chart->addAxis(axisY, Qt::AlignLeft);

    chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);

    rightLayout->addWidget(chartView);
    rightSection->setLayout(rightLayout);

    // Main Layout: Grid Layout for overall structure
    QGridLayout* mainLayout = new QGridLayout(this);
    mainLayout->addWidget(titleLabel, 0, 0, 1, 2); // Title spans top row
    mainLayout->addWidget(leftSection, 1, 0);      // Left section in the first column
    mainLayout->addWidget(rightSection, 1, 1);     // Right section in the second column
    mainLayout->setColumnStretch(0, 1); // Left section
    mainLayout->setColumnStretch(1, 2); // Right section (graph)

    // Set the final layout to the main widget
    setLayout(mainLayout);
}

void PollutionWindow::updatePollutantChart(const QString &pollutantName)
{
    try {
        WaterQualityDataset dataset;
        std::vector<std::pair<std::string, double>> pollutantSamples = dataset.getPollutant(pollutantName.toStdString());

        if (pollutantSamples.empty()) {
            std::cerr << "No data available for " << pollutantName.toStdString() << std::endl;
            return;
        }

        // Prepare data for the chart (average concentration per month)
        std::map<int, std::pair<double, int>> monthlyData;  // Store both sum and count (sum, count) for each month
        for (int month = 1; month <= 12; ++month) {
            monthlyData[month] = std::make_pair(0.0, 0);  // Initialize sum and count for each month
        }

        for (const auto& sample : pollutantSamples) {
            std::string sampleDate = sample.first;
            QDate date = QDate::fromString(QString::fromStdString(sampleDate).split("T")[0], "yyyy-MM-dd");

            if (date.isValid()) {
                int month = date.month();
                double concentration = sample.second;
                auto& data = monthlyData[month];

                // Accumulate the concentration and sample count for each month
                data.first += concentration;  // Sum of concentrations
                data.second += 1;  // Count the number of samples
            }
        }

        // Prepare a vector for sorting by average concentration
        std::vector<std::pair<int, double>> monthAverages;
        double highestAverage = 0.0;
        double lowestAverage = std::numeric_limits<double>::max();  // Initialize to a very high value

        for (const auto& entry : monthlyData) {
            int month = entry.first;
            double totalConcentration = entry.second.first;
            int sampleCount = entry.second.second;

            if (sampleCount > 0) {
                double averageConcentration = totalConcentration / sampleCount;
                monthAverages.push_back(std::make_pair(month, averageConcentration));

                if (averageConcentration > highestAverage) {
                    highestAverage = averageConcentration;
                }
                if (averageConcentration < lowestAverage) {
                    lowestAverage = averageConcentration;
                }
            }
        }

        // Sort months by average concentration in descending order
        std::sort(monthAverages.begin(), monthAverages.end(), [](const std::pair<int, double>& a, const std::pair<int, double>& b) {
            return a.second > b.second;
        });

        // Select the top 12 months
        QScatterSeries* series = new QScatterSeries();
        series->setName(pollutantName);

        int count = std::min(12, (int)monthAverages.size());
        for (int i = 0; i < count; ++i) {
            int month = monthAverages[i].first;
            double average = monthAverages[i].second;

            // Add the point to the scatter series
            series->append(month, average);

            // Set the point labels format, but leave it hidden initially
            series->setPointLabelsVisible(false);  // Set false to not display the label until hovered
        }

        // Update the chart
        chart->removeAllSeries();
        chart->addSeries(series);
        series->attachAxis(axisX);
        series->attachAxis(axisY);

        chart->setTitle(pollutantName + " Monthly Average Concentration Levels");

        // Set Y-axis range dynamically based on the highest and lowest averages
        double yMin = std::max(0.0, lowestAverage * 0.9);  // Set the minimum to 0 or 90% of the lowest average if it's small
        double yMax = highestAverage * 1.1;  // Set the maximum to 110% of the highest average
        axisY->setRange(yMin, yMax);  // Update the Y-axis range

        // Draw threshold lines
        auto threshold = thresholds[pollutantName];
        double safeThreshold = std::get<0>(threshold);
        double amberThreshold = std::get<1>(threshold);
        double redThreshold = std::get<2>(threshold);

        QLineSeries* safeLine = new QLineSeries();
        safeLine->append(1, safeThreshold);
        safeLine->append(12, safeThreshold);
        safeLine->setPen(QPen(Qt::green, 2));
        chart->addSeries(safeLine);
        safeLine->attachAxis(axisX);
        safeLine->attachAxis(axisY);

        QLineSeries* amberLine = new QLineSeries();
        amberLine->append(1, amberThreshold);
        amberLine->append(12, amberThreshold);
        amberLine->setPen(QPen(Qt::yellow, 2));
        chart->addSeries(amberLine);
        amberLine->attachAxis(axisX);
        amberLine->attachAxis(axisY);

        QLineSeries* redLine = new QLineSeries();
        redLine->append(1, redThreshold);
        redLine->append(12, redThreshold);
        redLine->setPen(QPen(Qt::red, 2));
        chart->addSeries(redLine);
        redLine->attachAxis(axisX);
        redLine->attachAxis(axisY);

        // Handle hover event to show additional details
        connect(series, &QScatterSeries::hovered, [=](const QPointF& point, bool state) {
            if (state) {
                int hoveredMonth = static_cast<int>(point.x());
                double concentration = point.y();
                int total = monthlyData.at(hoveredMonth).first;  // Use at() to avoid modifying the map
                int count = monthlyData.at(hoveredMonth).second; // Use at() for safe access

                QString tooltipText = QString(tr("Month: %1\nAverage Concentration: %2 ug/L\nTotal Concentration: %3 ug/L\nPollutant Frequency: %4"))
                                          .arg(hoveredMonth)
                                          .arg(concentration, 0, 'f', 7)  // Format concentration to 7 decimal places
                                          .arg(total)
                                          .arg(count);

                QToolTip::showText(QCursor::pos(), tooltipText);
            } else {
                QToolTip::hideText();  // Hide the tooltip when the hover ends
            }
        });

        // Handle click event to show additional details (useful for handling clicks on data points)
        connect(series, &QScatterSeries::clicked, [=](const QPointF& point) {
            int clickedMonth = static_cast<int>(point.x());
            double concentration = point.y();
            int total = monthlyData.at(clickedMonth).first;  // Use at() to avoid modifying the map
            int count = monthlyData.at(clickedMonth).second; // Use at() for safe access

            // Show a detailed message in a message box or dialog
            QString message = QString(tr("Month: %1\nAverage Concentration: %2 ug/L\nTotal Concentration: %3 ug/L\nPollutant Frequency: %4"))
                                  .arg(clickedMonth)
                                  .arg(concentration, 0, 'f', 7)  // Format concentration to 7 decimal places
                                  .arg(total)
                                  .arg(count);

            QMessageBox::information(this, "Data Point Details", message);
        });

    } catch (const std::exception& e) {
        std::cerr << "Error updating chart: " << e.what() << std::endl;
    }
}

void PollutionWindow::updatePollutantDescription(const QString &pollutantName)
{
    QString description = pollutantDescriptions[pollutantName];
    QString formattedDescription = "<p style='font-family:\"Times New Roman\"; font-size:14pt;'><b>" + pollutantName + "</b></p>";
    formattedDescription += "<p style='font-family:\"Times New Roman\"; font-size:12pt;'>" + description + "</p>";
    descriptionLabel->setText(formattedDescription);
}
