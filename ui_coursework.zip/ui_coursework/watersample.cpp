#include <stdexcept>
#include <sstream>
#include "watersample.hpp"
#include "dataset.hpp"
#include <fstream>

using namespace std;

std::ostream& operator<<(std::ostream& out, const WaterSample& sample) {
    return out
           << "Sample ID: " << sample.getId() << "\n"
           << "Sampling Point: " << sample.getSamplingPoint() << "\n"
           << "Sampling Point Notation: " << sample.getSamplingPointNotation() << "\n"
           << "Sampling Point Label: " << sample.getSamplingPointLabel() << "\n"
           << "Date/Time: " << sample.getDateTime() << "\n"
           << "Determinand Label: " << sample.getDeterminandLabel() << "\n"
           << "Determinand Definition: " << sample.getDeterminandDefinition() << "\n"
           << "Determinand Notation: " << sample.getDeterminandNotation() << "\n"
           << "Result Qualifier: " << (sample.getResultQualifier().empty() ? "N/A" : sample.getResultQualifier()) << "\n"
           << "Result: " << sample.getResult() << " " << sample.getUnitLabel() << "\n"
           << "Coded Result Interpretation: " << (sample.getCodedResultInterpretation().empty() ? "N/A" : sample.getCodedResultInterpretation()) << "\n"
           << "Sampled Material Type: " << sample.getSampledMaterialType() << "\n"
           << "Compliance Status: " << (sample.getCompliance() ? "Compliant" : "Non-Compliant") << "\n"
           << "Purpose Label: " << sample.getPurposeLabel() << "\n"
           << "Easting: " << sample.getEasting() << "\n"
           << "Northing: " << sample.getNorthing() << std::endl;
}
