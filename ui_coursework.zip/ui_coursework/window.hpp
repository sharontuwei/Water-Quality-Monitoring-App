#pragma once

#include <QMainWindow>
#include <QComboBox>
#include <QLabel>
#include <QPushButton>
#include <QTableView>
#include <vector>
#include <QFileDialog>
#include "model.hpp"
#include "dataset.hpp"
#include "pollutionWindow.hpp"

class StatsDialog;

class WaterQualityWindow : public QMainWindow
{
    Q_OBJECT

public:
    WaterQualityWindow(QWidget* parent = nullptr);

private:
    void createMainWidget();
    void createFileSelectors();
    void createButtons();
    void createToolBar();
    void createStatusBar();
    void addFileMenu();
    void addHelpMenu();

    WaterQualityModel waterQualityModel;
    WaterQualityDataset dataset; 
    QString dataLocation;
    QComboBox* countryFilter;
    QComboBox* yearFilter;
    QPushButton* loadButton;
    QPushButton* statsButton;
    QTableView* table; 
    QLabel* fileInfo;
    StatsDialog* statsDialog;

private slots:
    void setDataLocation();
    void openCSV();
    void displayStats();
    void about();
};
